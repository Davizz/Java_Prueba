package com.ludo.bdd.crud.config;


public class MyWebAppInitializer{

	

}
