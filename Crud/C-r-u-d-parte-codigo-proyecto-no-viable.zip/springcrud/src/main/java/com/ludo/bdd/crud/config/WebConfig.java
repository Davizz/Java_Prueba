package com.ludo.bdd.crud.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.ludo.bdd.crud.controller.MainController;
import com.ludo.bdd.crud.controller.UserController;

@Configuration
@EnableWebMvc
public class WebConfig implements WebMvcConfigurer {

	/* EQUIVALENCIA
	 <bean id="viewResolver" class="org.springframework.web.servlet.view.InternalResourceViewResolver">
	   <property name="viewClass" value="org.springframework.web.servlet.view.JstlView"/>
	   <property name="prefix" value="/WEB-INF/views/"/>
	   <property name="suffix" value=".jsp"/>
	 </bean>
	*/
	@Bean
	public InternalResourceViewResolver resolver() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setViewClass(JstlView.class);
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		return resolver;
	}
	
	/*
	 <bean id="messageSource" class="org.springframework.context.support.ResourceBundleMessageSource">
	   <property name="basename" value="messages"/>
	 </bean>
	 */

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}
	
	@Bean
	public MainController myMainController() {
		return new MainController();
	}
	
	@Bean
	public UserController myUserController() {
		return new UserController();
	}
}
